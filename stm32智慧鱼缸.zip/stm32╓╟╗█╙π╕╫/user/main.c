#include "stm32f10x.h" //标准库
#include "Delay.h"     //延时函数库 
#include "OLED_I2C.h"  //OLED屏幕显示库
#include "key.h"       //按键配置
#include "LED.h"
#include "AD.h"
#include "ds18b20.h"   //温度检测
#include "ds1302.h"    //时间模块
#include "Servo.h"     //舵机函数

#define Device_1_ON() GPIO_SetBits(GPIOB,GPIO_Pin_13);       //设备1开
#define Device_1_OFF() GPIO_ResetBits(GPIOB,GPIO_Pin_13);    //设备1关
#define Device_2_ON() GPIO_SetBits(GPIOB,GPIO_Pin_14);      //设备2开
#define Device_2_OFF() GPIO_ResetBits(GPIOB,GPIO_Pin_14);   //设备2关

#define KEY_ENTER GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_9)  //确定
#define KEY_MENU GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_10)  //菜单
#define KEY_MINUS GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_11) //减
#define KEY_ADD GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_12)   //加

//OLED显示状态
enum State {
	Normal,
	State_Temp_Min,
	State_Temp_Max,
	State_Device_Control_1,
	State_Device_Control_2,
	State_Set_time_hour,
	State_Set_time_min,
	State_Set_hunzhuo

}OLED_state;

void KEY();
void OLED_Normal();
unsigned char Temp_Max=32;   //初始化温度上限
unsigned char Temp_Min=10;   //初始化温度下限;
extern const unsigned char BMP1[];
extern u8 dat[5];
float temper =0;
uint16_t Device_1=0;
uint16_t Device_2=0;
uint16_t Set_hour=15;
uint16_t Set_min=34;
uint16_t Auto=0;
uint16_t ADValue=0;
uint16_t Set_ADValue=40;  //设置水质浑浊度阈值 
uint8_t flag=0;

//OLED屏幕显示
void OLED_Normal()
{
	OLED_ShowNum(0,0,TimeData.month,2,16);    //月
	OLED_ShowStr(16,0,"-",2);
	OLED_ShowNum(24,0,TimeData.day,2,16);     //日
	
	OLED_ShowNum(62,0,TimeData.hour,2,16);     //时
	OLED_ShowStr(78,0,":",2);
  OLED_ShowNum(84,0,TimeData.minute,2,16);   //分
	OLED_ShowStr(100,0,":",2);
	OLED_ShowNum(108,0,TimeData.second,2,16);  //秒
	
	OLED_ShowCN(0,2,0);		      //温
	OLED_ShowCN(16,2,1);	    	//度
  OLED_ShowStr(32,2,":",2);
  OLED_ShowNum(40,2,temper/1,2,16);    //温度整数部分
	OLED_ShowStr(56,2,".",2);
	OLED_ShowNum(62,2,(u32)(temper*100)%100,2,16);    //温度小数部分
	OLED_ShowCN(80,2,4);		    //°C	 
	
	OLED_ShowCN(0,4,22);		  //浑
	OLED_ShowCN(16,4,23);	  	//浊 
	OLED_ShowCN(32,4,1);		  //度
	OLED_ShowStr(48,4,":",2);
	OLED_ShowNum(64,4, ADValue/40,2,16);
	
	OLED_ShowCN(0,6,0);		  //温 
	OLED_ShowCN(16,6,1);		//度
	OLED_ShowCN(32,6,11);		//区
	OLED_ShowCN(48,6,12);		//间
	OLED_ShowNum(64,6,Temp_Min,2,16);    //温度最低值
	OLED_ShowCN(80,6,13);     					 //~    
	OLED_ShowNum(96,6,Temp_Max,2,16);    //温度最高值
	OLED_ShowCN(112,6,4);		//°C
	
	Delay_ms(60);
}

void OLED_State_Temp_Min()
{
	OLED_ShowCN(0,0,0);		  //温
	OLED_ShowCN(16,0,1);		//度
	OLED_ShowCN(32,0,6);		//下
	OLED_ShowCN(48,0,7);		//限
	OLED_ShowCN(100,0,4);		//°C
	OLED_ShowNum(32,4,Temp_Min,2,16);    //温度下限值
	OLED_ShowNum(80,4,Temp_Max,2,16);    //温度上限值
	OLED_ShowCN(32,2,10);      //下箭头
	OLED_ShowCN(32,6,9);       //上箭头
	Delay_ms(60);
	
}

void OLED_State_Temp_Max()
{
	OLED_ShowCN(0,0,0);		  //温
	OLED_ShowCN(16,0,1);		//度
	OLED_ShowCN(32,0,8);		//上
	OLED_ShowCN(48,0,7);		//限
  OLED_ShowCN(100,0,4);		//°C
	OLED_ShowNum(32,4,Temp_Min,2,16);    //温度下限值
	OLED_ShowNum(80,4,Temp_Max,2,16);    //温度上限值
	OLED_ShowCN(80,2,10);   //下箭头
	OLED_ShowCN(80,6,9);    //上箭头
	Delay_ms(60);
}

void OLED_State_Device_Control_1()
{
	OLED_ShowCN(0,0,16);	  	//设
	OLED_ShowCN(16,0,17);		  //备
	OLED_ShowStr(32,0,"1",2); //1
	OLED_ShowStr(48,0,":",2);
	
	OLED_ShowCN(0,2,16);	  	//设
	OLED_ShowCN(16,2,17);		  //备
	OLED_ShowStr(32,2,"2",2); //2
	OLED_ShowStr(48,2,":",2);
	
	if(Device_1==0)      //设备一
	{
		OLED_ShowCN(70,0,15);	  	//关
	}
	else
	{
		OLED_ShowCN(70,0,14);	  	//开
	}
	OLED_ShowCN(100,0,9);       //上箭头

	if(Device_2==0)     //设备二
	{
		OLED_ShowCN(70,2,15);	  	//关
	}
	else
	{
		OLED_ShowCN(70,2,14);	  	//开
	}
	
	Delay_ms(60);
}

void OLED_State_Device_Control_2()
{
	OLED_ShowCN(0,0,16);	  	//设
	OLED_ShowCN(16,0,17);		  //备
	OLED_ShowStr(32,0,"1",2); //1
	OLED_ShowStr(48,0,":",2);
	
	OLED_ShowCN(0,2,16);	  	//设
	OLED_ShowCN(16,2,17);		  //备
	OLED_ShowStr(32,2,"2",2); //2
	OLED_ShowStr(48,2,":",2);
	
	if(Device_1==0)      //设备一
	{
		OLED_ShowCN(70,0,15);	  	//关
	}
	else
	{
		OLED_ShowCN(70,0,14);	  	//开
	}
	
	if(Device_2==0)     //设备二
	{
		OLED_ShowCN(70,2,15);	  	//关
	}
	else
	{
		OLED_ShowCN(70,2,14);	  	//开
	}
	OLED_ShowCN(100,2,9);       //上箭头
	Delay_ms(60);
}

void Set_time_hour(void)
{
	OLED_ShowCN(0,0,16);	  	//设
	OLED_ShowCN(16,0,18);		  //置
	OLED_ShowCN(32,0,19);	  	//饲
	OLED_ShowCN(48,0,20);		  //喂
	OLED_ShowCN(64,0,21);	  	//时
	OLED_ShowCN(80,0,12);		  //间

	OLED_ShowNum(16,4,Set_hour,2,16);    //时
	OLED_ShowStr(32,4,":",2);
	OLED_ShowNum(48,4,Set_min,2,16);    //分
	OLED_ShowCN(16,2,10);    //下箭头
	OLED_ShowCN(16,6,9);     //上箭头
	
	Delay_ms(60);
}


void Set_time_min()
{
	OLED_ShowCN(0,0,16);	  	//设
	OLED_ShowCN(16,0,18);		  //置
	OLED_ShowCN(32,0,19);	  	//饲
	OLED_ShowCN(48,0,20);		  //喂
	OLED_ShowCN(64,0,21);	  	//时
	OLED_ShowCN(80,0,12);		  //间

	OLED_ShowNum(16,4,Set_hour,2,16);    //时
	OLED_ShowStr(32,4,":",2);
	OLED_ShowNum(48,4,Set_min,2,16);    //分
	OLED_ShowCN(48,2,10);    //下箭头
	OLED_ShowCN(48,6,9);     //上箭头
	
	Delay_ms(60);
}

void Set_hunzhuo()
{
	OLED_ShowCN(0,0,16);	  	//设
	OLED_ShowCN(16,0,18);		  //置
	OLED_ShowCN(32,0,22);		  //浑
	OLED_ShowCN(48,0,23);	  	//浊 
	OLED_ShowCN(64,0,1);		  //度

	OLED_ShowNum(48,4,Set_ADValue,2,16);    
	OLED_ShowCN(48,2,10);    //下箭头
	OLED_ShowCN(48,6,9);     //上箭头
}


void KEY()
{
	if(KEY_MENU == 0)
	{
		Delay_ms(10);
		if(KEY_MENU == 0)
		{		
			if(OLED_state == State_Set_hunzhuo)
			{OLED_state = Normal;}
			else 
			{OLED_state=OLED_state+1;}
			while(KEY_MENU == 0);
	  	OLED_CLS();//清屏		
		}	
	}
	
	if(KEY_MINUS == 0)
	{
		Delay_ms(10);
		if(KEY_MINUS == 0)
		{
			switch(OLED_state)
			{
				case State_Temp_Min:
					Temp_Min--;
				  break;
		  	case State_Temp_Max:
					Temp_Max--;
					break;
				case State_Device_Control_1:
					Device_1=0;
					break;
				case State_Device_Control_2:
					Device_2=0;
					break;
				case State_Set_time_hour:
					Set_hour--;     					  	//设置时
				break;
				case State_Set_time_min:
					Set_min--;   					 		  //设置分
				break;
				case State_Set_hunzhuo:
					Set_ADValue--;
				break;
			}
			while(KEY_MINUS == 0);	
		}
	}
	
	if(KEY_ADD == 0)
	{
		Delay_ms(10);
		if(KEY_ADD == 0)
		{
			switch(OLED_state)
			{
				case State_Temp_Min:
					Temp_Min++;
				  break;
		  	case State_Temp_Max:
					Temp_Max++;
					break;
				case State_Device_Control_1:
					Device_1=1;
					break;
				case State_Device_Control_2:
					Device_2=1;
					break;
				case State_Set_time_hour:
					Set_hour++;     					  	//设置时
				break;
				case State_Set_time_min:
					Set_min++;   					 		  //设置分
				break;
				case State_Set_hunzhuo:
					Set_ADValue++;
				break;
			}
			while(KEY_ADD == 0);			
		}
	}
	
	if(KEY_ENTER == 0)
	{
		Delay_ms(10);
		if(KEY_ENTER == 0)
		{
			OLED_state = Normal;
			while(KEY_ENTER == 0);
			OLED_CLS();//清屏
		}
	}
}

//对温度以及水质进行判断
void Judge()
{
	if(Auto==0)
	{
		if(temper<Temp_Min || temper>Temp_Max)
		{
			Device_1_ON();
		}
		else
		{
			Device_1_OFF();
		}
		if((int)(ADValue/40)<=Set_ADValue)
		{
			Device_2_ON();
		}
		else
		{
			Device_2_OFF();
		}
	}
	else
	{
		if(Device_1==0)
		{
			Device_1_OFF();
		}
		else
		{
			Device_1_ON();
		}
		
		if(Device_2==0)
		{
			Device_2_OFF();
		}
		else
		{
			Device_2_ON();
		}
	}
	if(flag ==0)
	{
		if(Set_hour==TimeData.hour && Set_min==TimeData.minute)
		{
			Servo_SetAngle(170);
			Delay_ms(800);
			flag=1;
		}
	}
	if(Set_hour==TimeData.hour && (Set_min+1)==TimeData.minute)
	{
		flag=0;
	}
}

int main(void)
{
	NVIC_Configuration();
	I2C_Configuration(); 		 //初始化硬件IIC引脚
	OLED_state = Normal; 		 //设置OLED显示模式
	OLED_Init();          		//OLED初始化
	Device_Control_Init();		//设备引脚初始化
	Device_1_OFF();
	Device_2_OFF();
  KEY_Init();							//按键初始化
	Servo_Init();           //舵机初始化
	
	AD_Init();
	ds1302_gpio_init();   	//ds1302端口初始化
	Delay_ms(5);
  ds1032_DATAOUT_init();  //IO端口配置为输出
  ds1032_DATAINPUT_init();//IO端口配置为输入
	//ds1032_init();        //设置初始时间函数
	Delay_ms(5);
	OLED_CLS();         	  //清屏
	DS18B20_Init();    		  //温度检测格式化  
  Delay_ms(50);
	
	while(1)
	{
	  KEY();
		Judge();
		Servo_SetAngle(10);
		switch(OLED_state)
		{
			case Normal:
				Auto=0;          //改为自动模式
				ds1032_read_realTime();
				OLED_Normal();
				ADValue = AD_GetValue();
				temper=DS18B20_GetTemperture();
				Delay_ms(50);      
				break;
			case State_Temp_Min:
				OLED_State_Temp_Min();      //温度下限
				break;
			case State_Temp_Max:
				OLED_State_Temp_Max();      //温度上限
				break;
			case State_Device_Control_1:
				Auto=1;  //将其改为手动模式
				OLED_State_Device_Control_1();    //设备一控制
				break;	
			case State_Device_Control_2:
				Auto=1;  //将其改为手动模式
				OLED_State_Device_Control_2();    //设备二控制
				break;
			case State_Set_time_hour:
				Set_time_hour();     					  	//设置时
				break;
			case State_Set_time_min:
				Set_time_min();   					 		  //设置分
				break;
			case State_Set_hunzhuo:
				Set_hunzhuo();   					 		  //设置浑浊度阈值
				break;
		}	
	} 
}


