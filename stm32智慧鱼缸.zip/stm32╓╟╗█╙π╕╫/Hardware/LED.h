#ifndef __LED_H
#define __LED_H

void Device_Control_Init(void);
void Buzzer_Init(void);

#endif
